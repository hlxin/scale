# Changelog

## 1.1.1

Exported from scale-graph 0.1.0 (ex:msyn/graph/co-co2-hydrogenation); previous release 1.1.0. Nodes: 0 added, 0 removed, 0 changed; edges: 0 added, 0 removed, 0 changed.

- **Title.** The bundle's title, which a host shows as the graph's name on import, is now "Methanol Synthesis CO/CO2+H2
  Pre1966" (`topic`, and the schema's `title`). The scope it stood for in full (105 sources, 1923–1965, curated from the
  source texts) is in the bundle's scope and the graph's description. Nothing else changed.

## 1.1.0

Exported from scale-graph 0.1.0 (ex:msyn/graph/co-co2-hydrogenation) in format 1.1.0; previous release 1.0.0. Nodes: 13 added, 0 removed, 1513 changed; edges: 3456 added, 0 removed, 552 changed.

- **Withheld-quote evidence carried.** The links 1.0.0 left out because every quote of theirs is withheld under SCALE's
  copyright cap are now edges: 3,274 substantive edges rest only on withheld quotes (6,757 withheld items in all),
  each with its source, page and the quote's sha256 and length (`quote_withheld`, normalization `scale-match-text-1`),
  so a reader with the source can find and check the passage. One withheld quote longer than 600 characters is left
  out. The 13 added nodes are those whose only provenance was such a link.
- **Typed absences carried.** 227 values the sources do not report are `_value_status` entries (`not_reported`, with
  the reason), so "the source does not report the pressure" is an answer, not a gap.
- **Corrections.** Nine runs of Molstad and Dodge (1935, 10.1021/ie50302a005) now carry the testing pressure their
  Experimental Procedure states (178 atmospheres absolute, 17.8 MPa), cited to that passage.

### Schema

1.0.0 → 1.1.0 (minor, additive): edge types DESCRIBES_REACTION, HAS_ELEMENTARY_STEP, HAS_OPERATION and REPLICATES
added (links that 1.0.0 left out); optional properties added: COMPETES_WITH, FEEDS_INTO and IDENTIFIED_AS `note`,
DETECTS `negated`, PREPARED_FROM `supplier`, USES_CATALYST `amount_qualifier`. Nothing renamed or removed. `extends`
names scale-graph 0.1.0 by its spec sha256 (3c2fa720…02006).

## 1.0.0

First release, exported from scale-graph 0.1.0 (ex:msyn/graph/co-co2-hydrogenation).

The graph is the SCALE knowledge-graph release v1.0.0 of examples/methanol-synthesis-pre1966 (hlxin/scale): methanol
synthesis from CO/CO2 + H2, 105 sources published before 1966-01-01, scale-graph 0.1.0 (spec sha256
3c2fa7205a7bae5e0bbfa7d87826ff7ab7803e78536129064101c7d5a2c02006).

### Not carried over

- 3277 links (ABOUT 629, HAS_COMPONENT 353, SUPPORTS 339, FED_WITH 225, PREPARED_FROM 219, OF_REACTION 187, ...) whose every quote is withheld under SCALE's copyright cap (in-copyright sources quote at
  most 4,000 distinct characters and 10 % of their text; the rest is kept as sha256 and length). Format 1.0.0 needs
  a verbatim quote on every edge, so they are left out here; they stay in the SCALE graph with their source, locator
  and passage.
- 229 values the sources do not report (typed absences in SCALE; format 1.0.0 has no field for them).

